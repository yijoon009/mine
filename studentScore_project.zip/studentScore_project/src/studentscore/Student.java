package studentscore;

public class Student {
	
	private String name;
	private int num;
	static public int Fnum=1001;
	
	public Student() {;}

	public Student(String name) {
		super();
		this.name = name;
		this.num = Fnum;
		Fnum++;
	}



	public int getNum() {
		return num;
	}



	public void setNum(int num) {
		this.num = num;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	void show() {
		System.out.println("\n�й�: "+this.num+"   �̸�: "+this.name);
	}
	
	
	
}
