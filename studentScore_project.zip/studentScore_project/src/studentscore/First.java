package studentscore;

import java.util.Scanner;

public class First {

	private String school;
	private String grade;
	private String teacher;
	private String class_name;
	
	public First() {;}
	
	
	public First(String school, String grade, String teacher, String class_name) {
		super();
		this.school = school;
		this.grade = grade;
		this.teacher = teacher;
		this.class_name = class_name;
	}


	
	public String getSchool() {
		return school;
	}


	public void setSchool(String school) {
		this.school = school;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	public String getTeacher() {
		return teacher;
	}


	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}


	public String getClass_name() {
		return class_name;
	}


	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}


	public void firstOutput() {
		
		System.out.println("\n�ĢĢĢĢĢĢ��л� ���� ���� ���α׷��ŢŢŢŢŢŢ�");
		System.out.println("�б���: "+this.school+"       �г�: "+this.grade);
		System.out.println("����: "+this.teacher+"       ��: "+this.class_name);
	}
	
}
